**Species:** *Pseudocohnilembus pussilus*

**Phylum:** Intramacronucleata

**Class:** Oligohymenophorea

|      | **Morphology** |
| :--- | :------------: |
| B    |  |
| δB   |  |
| W    |  |
| δW   |  |
|      | **Cilia** |
| N    |  |
| δN   |  |
| L    |  |
| δL   |  |
| d    |  |
| δd   |  |
| κ    |  |
| δκ   |  |
|      | **Kinematics** |
| U    | 320 |
| δU   |  |
| f    |  |
| δf   |  |
| λmw  |  |
| δλmw |  |

**Notes:**

1. **λmw:** Wavelength of metachronal waves;

**References:**

1. Hansen PJ, Bjørnsen PK, Hansen BW.  Zooplankton grazing and growth:  Scaling within the 2-2,000-μm body sizerange.  Limnology and Oceanography. 1997;42(4):687–704.
