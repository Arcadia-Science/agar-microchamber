**Species:** *Nassula ambigua*

**Phylum:** Intramacronucleata

**Class:** Nassophorea

|      | **Morphology** |
| :--- | :------------: |
| B    | 143 |
| δB   | 25 |
| W    | 69 |
| δW   | 10 |
|      | **Cilia** |
| N    |  |
| δN   |  |
| L    |  |
| δL   |  |
| d    |  |
| δd   |  |
| κ    |  |
| δκ   |  |
|      | **Kinematics** |
| U    | 2004 |
| δU   |  |
| f    |  |
| δf   |  |
| λmw  |  |
| δλmw |  |

**Notes:**

1. **λmw:** Wavelength of metachronal waves;

**References:**

1. Bullington WE.  A study of spiral movement in the ciliate infusoria.  Arch Protistenkd. 1925;50:219—74.
