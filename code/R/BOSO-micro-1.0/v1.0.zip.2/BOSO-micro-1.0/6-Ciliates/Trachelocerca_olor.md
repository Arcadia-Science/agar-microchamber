**Species:** *Trachelocerca olor*

**Phylum:** Postciliodesmatophora

**Class:** Karyorelictea

|      | **Morphology** |
| :--- | :------------: |
| B    | 267.5 |
| δB   | 32.5 |
| W    | 37.5 |
| δW   | 2.5 |
|      | **Cilia** |
| N    |  |
| δN   |  |
| L    |  |
| δL   |  |
| d    |  |
| δd   |  |
| κ    |  |
| δκ   |  |
|      | **Kinematics** |
| U    | 900 |
| δU   |  |
| f    |  |
| δf   |  |
| λmw  |  |
| δλmw |  |

**Notes:**

1. **λmw:** Wavelength of metachronal waves;

**References:**

1. Bullington WE.  A study of spiral movement in the ciliate infusoria.  Arch Protistenkd. 1925;50:219—74.
