**Species:** *Cepedea sp*

**Phylum:** Placidozoa (Heterokont)

**Class:** Opalinea

|      | **Morphology** |
| :--- | :------------: |
| B    | 333 |
| δB   |  |
| W    | 148.5 |
| δW   |  |
|      | **Cilia** |
| N    |  |
| δN   |  |
| L    | 25 |
| δL   |  |
| d    |  |
| δd   |  |
| κ    |  |
| δκ   |  |
|      | **Kinematics** |
| U    |  |
| δU   |  |
| f    |  |
| δf   |  |
| λmw  | 37 |
| δλmw |  |

**Notes:**

1. **λmw:** Wavelength of metachronal waves;

**References:**

1. Parducz B.  Ciliary movement and coordination in ciliates.  Jpn J Exp Med. 1967;14:19–28.
