**Species:** *Opalina obtrigonoidea*

**Phylum:** Placidozoa (Heterokont)

**Class:** Opalinea

|      | **Morphology** |
| :--- | :------------: |
| B    | 363 |
| δB   |  |
| W    | 113.8 |
| δW   | 9 |
|      | **Cilia** |
| N    |  |
| δN   |  |
| L    | 21.63 |
| δL   |  |
| d    | 4.7 |
| δd   | 2.9 |
| κ    |  |
| δκ   |  |
|      | **Kinematics** |
| U    |  |
| δU   |  |
| f    |  |
| δf   |  |
| λmw  |  |
| δλmw |  |

**Notes:**

1. **λmw:** Wavelength of metachronal waves;

**References:**

1. Parducz B.  Ciliary movement and coordination in ciliates.  Jpn J Exp Med. 1967;14:19–28.
