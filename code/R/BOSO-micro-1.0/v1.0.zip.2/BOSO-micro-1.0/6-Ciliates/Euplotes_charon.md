**Species:** *Euplotes charon*

**Phylum:** Intramacronucleata

**Class:** Spirotrichea

|      | **Morphology** |
| :--- | :------------: |
| B    | 66 |
| δB   | 17 |
| W    | 51.5 |
| δW   | 17.5 |
|      | **Cilia** |
| N    |  |
| δN   |  |
| L    |  |
| δL   |  |
| d    |  |
| δd   |  |
| κ    |  |
| δκ   |  |
|      | **Kinematics** |
| U    | 1053 |
| δU   |  |
| f    |  |
| δf   |  |
| λmw  |  |
| δλmw |  |

**Notes:**

1. **λmw:** Wavelength of metachronal waves;

**References:**

1. Bullington WE.  A study of spiral movement in the ciliate infusoria.  Arch Protistenkd. 1925;50:219—74.
