**Species:** *Nassula ornata*

**Phylum:** Intramacronucleata

**Class:** Nassophorea

|      | **Morphology** |
| :--- | :------------: |
| B    | 282 |
| δB   |  |
| W    | 90 |
| δW   |  |
|      | **Cilia** |
| N    |  |
| δN   |  |
| L    |  |
| δL   |  |
| d    |  |
| δd   |  |
| κ    |  |
| δκ   |  |
|      | **Kinematics** |
| U    | 750 |
| δU   |  |
| f    |  |
| δf   |  |
| λmw  |  |
| δλmw |  |

**Notes:**

1. **λmw:** Wavelength of metachronal waves;

**References:**

1. Bullington WE.  A study of spiral movement in the ciliate infusoria.  Arch Protistenkd. 1925;50:219—74.
