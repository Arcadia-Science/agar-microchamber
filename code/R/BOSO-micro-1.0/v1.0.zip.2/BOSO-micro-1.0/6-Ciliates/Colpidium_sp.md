**Species:** *Colpidium sp*

**Phylum:** Intramacronucleata

**Class:** Oligohymenophorea

|      | **Morphology** |
| :--- | :------------: |
| B    | 79.1 |
| δB   |  |
| W    | 38.6 |
| δW   |  |
|      | **Cilia** |
| N    |  |
| δN   |  |
| L    |  |
| δL   |  |
| d    |  |
| δd   |  |
| κ    |  |
| δκ   |  |
|      | **Kinematics** |
| U    |  |
| δU   |  |
| f    |  |
| δf   |  |
| λmw  | 10 |
| δλmw |  |

**Notes:**

1. **λmw:** Wavelength of metachronal waves;

**References:**

1. Machemer H.  Ciliary activity and metachronism in protozoa.  In:  Sleigh MA, editor. Cilia and Flagella. London:Academic Press; 1974. p. 199–287
