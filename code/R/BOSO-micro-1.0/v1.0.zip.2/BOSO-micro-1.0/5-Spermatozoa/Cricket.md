**Species:** *Cricket*

**Phylum:** Arthropoda

**Class:** Insecta

|    | **Morphology** |
|:-- | :------------: |
| B  | 110 |
| δB | 10 |
| W  |  |
| δW |  |
|    | **Flagellum** |
| L  | 870 |
| δL | 31.6 |
| λ  | 20 |
| δλ |  |
| h  | 0.9 |
| δh |  |
|    | **Kinematics** |
| U  |  |
| δU |  |
| f  | 13.3 |
| δf | 3.4 |
| Ω  |  |
| δΩ |  |

**Notes:**

1.

**References:**

1. Rikmenspoel R, Jacklet AC.  Motion characteristics of flagellar fragments of long insect sperm.  Biophys J.1980;29:295–304.
