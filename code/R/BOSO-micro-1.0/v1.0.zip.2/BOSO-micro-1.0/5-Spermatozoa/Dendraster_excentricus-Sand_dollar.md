**Species:** *Dendraster excentricus-Sand dollar*

**Phylum:** Echinodermata

**Class:** Echinoidea

|    | **Morphology** |
|:-- | :------------: |
| B  |  |
| δB |  |
| W  |  |
| δW |  |
|    | **Flagellum** |
| L  |  |
| δL |  |
| λ  |  |
| δλ |  |
| h  |  |
| δh |  |
|    | **Kinematics** |
| U  | 179.875 |
| δU | 107.925 |
| f  |  |
| δf |  |
| Ω  |  |
| δΩ |  |

**Notes:**

1.

**References:**

1. Larse PS, Riisgård HU.  Viscosity and not biological mechanisms often controls the effects of temperature on ciliary activity and swimming velocity of small aquatic organisms.  J Exp Mar Biol Ecol. 2009;381:67–73.
1. Robert D. Podolsky Lab website. Accessed: 07/07/2016. http://www.cofc.edu/~podolskyr/projects/latitude.htm
