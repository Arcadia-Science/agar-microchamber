**Species:** *Salmo salar-Atlantic salmon*

**Phylum:** Chordata

**Class:** Actinopterygii

|    | **Morphology** |
|:-- | :------------: |
| B  | 4.55 |
| δB | 0.95 |
| W  |  |
| δW |  |
|    | **Flagellum** |
| L  | 31.95 |
| δL | 3.75 |
| λ  |  |
| δλ |  |
| h  |  |
| δh |  |
|    | **Kinematics** |
| U  | 72.5 |
| δU | 54.5 |
| f  |  |
| δf |  |
| Ω  |  |
| δΩ |  |

**Notes:**

1.

**References:**

1. Gage MJG, Macfarlane C, Yeates S, Shackleton R, Parker GA.  Relationships between sperm morphometry and sperm motility in the Atlantic salmon.  J Fish Biol. 2002;61:1528–1539.
