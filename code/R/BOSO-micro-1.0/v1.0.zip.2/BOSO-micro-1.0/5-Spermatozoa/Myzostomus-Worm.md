**Species:** *Myzostomus-Worm*

**Phylum:** Annelida

**Class:** Polychaeta

|    | **Morphology** |
|:-- | :------------: |
| B  | 30.8 |
| δB | 4.55 |
| W  | 14.428 |
| δW |  |
|    | **Flagellum** |
| L  | 52 |
| δL | 2.5 |
| λ  | 28 |
| δλ | 3 |
| h  | 1.7 |
| δh | 0.6 |
|    | **Kinematics** |
| U  | 45.4 |
| δU | 18.3 |
| f  | 18.3 |
| δf | 2.9 |
| Ω  | 20.9 |
| δΩ | 4.4 |

**Notes:**

1.

**References:**

1. Ishijima S, Ishijima SA, Afzelius BA.  Movement of *Myzostomum* spermatozoa:  calcium ion regulation of swimming direction.  Cell Motil Cytosk. 1994;28:135–142.
