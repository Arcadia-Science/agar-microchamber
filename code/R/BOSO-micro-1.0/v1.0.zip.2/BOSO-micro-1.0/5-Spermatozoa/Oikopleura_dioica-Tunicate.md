**Species:** *Oikopleura dioica-Tunicate*

![alt text](https://github.com/marcos-fvr/BOSO-micro/blob/main/9-Figures/Oikopleura_spermatozoon.png)

**Phylum:** Chordata

**Class:** Appendicularia (Tunicata)

|    | **Morphology** |
|:-- | :------------: |
| B  | 1 |
| δB |  |
| W  | 1 |
| δW |  |
|    | **Flagellum** |
| L  | 28 |
| δL |  |
| λ  |  |
| δλ |  |
| h  |  |
| δh |  |
|    | **Kinematics** |
| U  | 75.61 |
| δU | 1.896 |
| f  |  |
| δf |  |
| Ω  |  |
| δΩ |  |

**Notes:**

1.

**References:**

1. Miller RL, King KR.  Sperm chemotaxis in *Oikopleura dioica* Fol. 1872 (Urochordata, Larvacea).  Biol Bull.1983;165:419–428.
1. Flood PR, Afzelius BA.  The spermatozoon of *Oikopleura dioica* Fol (Larvacea, Tunicata).  Cell Tissue Res.1978;191:27–37.
