**Species:** *Campanularia flexuosa-Hydroid*

![alt text](https://github.com/marcos-fvr/BOSO-micro/blob/main/9-Figures/Campanularia_spermatozoon.png)

**Phylum:** Cnidaria

**Class:** Hydrozoa

|    | **Morphology** |
|:-- | :------------: |
| B  | 3.5 |
| δB |  |
| W  | 0.81 |
| δW |  |
|    | **Flagellum** |
| L  | 40 |
| δL |  |
| λ  |  |
| δλ |  |
| h  |  |
| δh |  |
|    | **Kinematics** |
| U  | 165 |
| δU | 15 |
| f  |  |
| δf |  |
| Ω  |  |
| δΩ |  |

**Notes:**

1.

**References:**

1. Miller RL. Chemotaxis during fertilization in the hydroid *Campanularia*.  J Exp Zool. 1966;162:23–44.
