**Species:** *Echinus microtuberculatus-Sea urchin*

**Phylum:** Echinodermata

**Class:** Echinoidea

|    | **Morphology** |
|:-- | :------------: |
| B  |  |
| δB |  |
| W  |  |
| δW |  |
|    | **Flagellum** |
| L  |  |
| δL |  |
| λ  |  |
| δλ |  |
| h  |  |
| δh |  |
|    | **Kinematics** |
| U  | 120 |
| δU |  |
| f  |  |
| δf |  |
| Ω  |  |
| δΩ |  |

**Notes:**

1.

**References:**

1. Gray J.  The movement of sea urchin spermatozoa.  J Exp Biol. 1955;32:775–801.
