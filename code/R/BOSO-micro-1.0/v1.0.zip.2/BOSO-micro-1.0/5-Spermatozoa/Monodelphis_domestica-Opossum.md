**Species:** *Monodelphis domestica-Opossum*

**Phylum:** Chordata

**Class:** Mammalia

|    | **Morphology** |
|:-- | :------------: |
| B  | 17.65 |
| δB |  |
| W  | 8.77 |
| δW |  |
|    | **Flagellum** |
| L  | 237.94 |
| δL |  |
| λ  |  |
| δλ |  |
| h  |  |
| δh |  |
|    | **Kinematics** |
| U  | 304.5 |
| δU | 71.5 |
| f  |  |
| δf |  |
| Ω  |  |
| δΩ |  |

**Notes:**

1.

**References:**

1. Moore HDM, Taggart DA.  Sperm pairing in the opossum increases the efficiency of sperm movement in a viscous environment.  Biol Reprod. 1995;52:947–953.
