**Species:** *Guinea pig*

**Phylum:** Chordata

**Class:** Mammalia

|    | **Morphology** |
|:-- | :------------: |
| B  | 10.86 |
| δB |  |
| W  | 9.68 |
| δW |  |
|    | **Flagellum** |
| L  | 108.55 |
| δL |  |
| λ  |  |
| δλ |  |
| h  |  |
| δh |  |
|    | **Kinematics** |
| U  | 9.48 |
| δU | 0.4 |
| f  |  |
| δf |  |
| Ω  |  |
| δΩ |  |

**Notes:**

1.

**References:**

1. Cardullo RA, Baltz JM.  Metabolic regulation in mammalian sperm:  mitochondrial volume determines sperm length and flagellar beat frequency.  Cell Motil Cytosk. 1991;19:180–188.
1. Katz D, Yanagimachi R. Movement characteristics of hamster and guinea pig spermatozoa upon attachment to the zona pellucida.  Biol Reprod. 1981;25:785–791
