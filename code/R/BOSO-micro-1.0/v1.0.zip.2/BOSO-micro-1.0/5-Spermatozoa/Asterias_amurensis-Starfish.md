**Species:** *Asterias amurensis-Starfish*

![alt text](https://github.com/marcos-fvr/BOSO-micro/blob/main/9-Figures/Starfish_spermatozoon.png)

**Phylum:** Echinodermata

**Class:** Asteroidea

|    | **Morphology** |
|:-- | :------------: |
| B  |  |
| δB |  |
| W  |  |
| δW |  |
|    | **Flagellum** |
| L  |  |
| δL |  |
| λ  |  |
| δλ |  |
| h  |  |
| δh |  |
|    | **Kinematics** |
| U  | 259 |
| δU | 8 |
| f  | 43.3 |
| δf | 4.8 |
| Ω  | 2.3 |
| δΩ | 0.3 |

**Notes:**

1.

**References:**

1. Hiramoto Y, Baba S.  Quantitative analysis of flagellar movement in echinoderm spermatozoa.  J Exp Biol.1978;76:85–104.
