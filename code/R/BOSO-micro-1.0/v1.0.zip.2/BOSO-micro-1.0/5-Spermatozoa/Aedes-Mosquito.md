**Species:** *Aedes-Mosquito*

![alt text](https://github.com/marcos-fvr/BOSO-micro/blob/main/9-Figures/Aedes_spermatozoon.png)

**Phylum:** Arthropoda

**Class:** Insecta

|    | **Morphology** |
|:-- | :------------: |
| B  | 8.205 |
| δB | 0.365 |
| W  | 4.73 |
| δW | 0.6 |
|    | **Flagellum** |
| L  | 46 |
| δL |  |
| λ  |  |
| δλ |  |
| h  | 5 |
| δh |  |
|    | **Kinematics** |
| U  |  |
| δU |  |
| f  | 18.7 |
| δf | 15.3 |
| Ω  |  |
| δΩ |  |

**Notes:**

1.

**References:**

1. Swan MA.  The generation and propagation of double waves in mosquito (*Aedes notoscriptus*) sperm-tails.  GameteRes. 1981;4:241–250.
1. Breland OP, Eddleman CD, Biesele JJ.  Studies of insect spermatozoa I.  Entomol News. 1968;79:197–216.
