**Species:** *Ceratitis capitata-Fly*

**Phylum:** Arthropoda

**Class:** Insecta

|    | **Morphology** |
|:-- | :------------: |
| B  |  |
| δB |  |
| W  |  |
| δW |  |
|    | **Flagellum** |
| L  |  |
| δL |  |
| λ  | 17.5 |
| δλ | 12.5 |
| h  | 10.5 |
| δh | 9.5 |
|    | **Kinematics** |
| U  | 16 |
| δU |  |
| f  | 11 |
| δf | 9 |
| Ω  |  |
| δΩ |  |

**Notes:**

1.

**References:**

1. Werner M, Simmons LW.  Insect Sperm Motility.  Biol Rev. 2008;83:191–208.
1. Pak OS, Spagnolie SE, Lauga E.  Hydrodynamics of the double-wave structure of insect spermatozoa flagella.  J R SocInterface. 2012;9:1908–1924.
