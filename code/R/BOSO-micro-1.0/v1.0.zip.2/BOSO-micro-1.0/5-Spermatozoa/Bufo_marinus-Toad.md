**Species:** *Bufo marinus-Toad*

![alt text](https://github.com/marcos-fvr/BOSO-micro/blob/main/9-Figures/Toad_spermatozoon.png)

**Phylum:** Chordata

**Class:** Amphibia

|    | **Morphology** |
|:-- | :------------: |
| B  | 7.6 |
| δB |  |
| W  | 0.69 |
| δW |  |
|    | **Flagellum** |
| L  | 21.51 |
| δL |  |
| λ  | 20 |
| δλ |  |
| h  | 2.88 |
| δh | 1.13 |
|    | **Kinematics** |
| U  | 22.12 |
| δU | 15.9 |
| f  | 11.74 |
| δf | 3.2 |
| Ω  |  |
| δΩ |  |

**Notes:**

1.

**References:**

1. Swan MA, Linck RW, Ito S, Fawcett DW.  Structure and function of the undulating membrane in spermatozoanpropulsion in the toad *Bufo marinus*.  J Cell Biol. 1980;85:866–880.
