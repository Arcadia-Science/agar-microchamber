**Species:** *Coturnix coturnix var japonica-Quail*

**Phylum:** Chordata

**Class:** Aves

|    | **Morphology** |
|:-- | :------------: |
| B  |  |
| δB |  |
| W  |  |
| δW |  |
|    | **Flagellum** |
| L  | 208 |
| δL |  |
| λ  |  |
| δλ |  |
| h  |  |
| δh |  |
|    | **Kinematics** |
| U  | 50 |
| δU |  |
| f  |  |
| δf |  |
| Ω  | 4 |
| δΩ |  |

**Notes:**

1.

**References:**

1. Vernon GG, Woolley DM.  Three-dimensional motion of avian Spermatozoa.  Cell Motil Cytosk. 1999;42:149–161.
