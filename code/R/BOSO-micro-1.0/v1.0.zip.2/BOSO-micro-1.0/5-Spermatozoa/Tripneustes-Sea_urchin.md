**Species:** *Tripneustes-Sea urchin*

**Phylum:** Echinodermata

**Class:** Echinoidea

|    | **Morphology** |
|:-- | :------------: |
| B  |  |
| δB |  |
| W  |  |
| δW |  |
|    | **Flagellum** |
| L  |  |
| δL |  |
| λ  |  |
| δλ |  |
| h  |  |
| δh |  |
|    | **Kinematics** |
| U  |  |
| δU |  |
| f  | 60 |
| δf |  |
| Ω  |  |
| δΩ |  |

**Notes:**

1.

**References:**

1. Brokaw CJ, Gibbons IR.  Mechanisms of movement in flagella and cilia.  In:  Wu TYT, Brokaw CJ, Brennen C, editors. Swimming and Flying in Nature. New York:  Plenum; 1975. p. 89–132
