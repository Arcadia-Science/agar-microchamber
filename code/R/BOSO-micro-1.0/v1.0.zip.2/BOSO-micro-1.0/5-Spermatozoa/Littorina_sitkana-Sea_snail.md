**Species:** *Littorina sitkana-Sea snail*

![alt text](https://github.com/marcos-fvr/BOSO-micro/blob/main/9-Figures/Snail_spermatozoon.png)

**Phylum:** Mollusca

**Class:** Gastropoda

|    | **Morphology** |
|:-- | :------------: |
| B  | 27 |
| δB |  |
| W  | 1 |
| δW |  |
|    | **Flagellum** |
| L  | 25.4 |
| δL |  |
| λ  |  |
| δλ |  |
| h  |  |
| δh |  |
|    | **Kinematics** |
| U  | 109 |
| δU | 91 |
| f  |  |
| δf |  |
| Ω  |  |
| δΩ |  |

**Notes:**

1.

**References:**

1. Buckland-Nicks JA, Chia FS.  Locomotion of the filiform sperm of *Littorina* (Gastropoda, Prosobranchia).  Cell Tissue Res. 1981;219:27–39.
