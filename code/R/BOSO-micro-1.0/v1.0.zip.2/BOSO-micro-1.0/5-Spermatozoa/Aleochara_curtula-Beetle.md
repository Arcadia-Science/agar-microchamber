**Species:** *Aleochara curtula-Beetle*

**Phylum:** Arthropoda

**Class:** Insecta

|    | **Morphology** |
|:-- | :------------: |
| B  | 15.4 |
| δB | 0.44 |
| W  | 7.214 |
| δW |  |
|    | **Flagellum** |
| L  | 84.8 |
| δL | 12.81 |
| λ  | 10.75 |
| δλ | 3.75 |
| h  | 1.45 |
| δh | 0.65 |
|    | **Kinematics** |
| U  | 9.45 |
| δU | 5.75 |
| f  | 23.15 |
| δf | 16.05 |
| Ω  |  |
| δΩ |  |

**Notes:**

1.

**References:**

1. Werner M, Tscheulin T, Speck T, Zissler D, Peschke K. Ultrastructure and motility pattern of the spermatozoa of *Aleochara curtula* (Coleoptera, Staphylinidae).  Arthropod Struct Dev. 2002;31:243–254
