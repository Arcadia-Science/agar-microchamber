**Species:** *Cyprinus carpio-Carp*

**Phylum:** Chordata

**Class:** Actinopterygii

|    | **Morphology** |
|:-- | :------------: |
| B  |  |
| δB |  |
| W  |  |
| δW |  |
|    | **Flagellum** |
| L  |  |
| δL |  |
| λ  |  |
| δλ |  |
| h  |  |
| δh |  |
|    | **Kinematics** |
| U  | 140 |
| δU |  |
| f  | 53 |
| δf |  |
| Ω  |  |
| δΩ |  |

**Notes:**

1.

**References:**

1. Cosson J.  Frenetic activation of fish spermatozoa flagella entails short-term motility, portending their precocious decadence.  J Fish Biolog. 2010;76:240–279.
