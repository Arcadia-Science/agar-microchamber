**Species:** *Hemicentrotus pulcherrimus-Sea urchin*

**Phylum:** Echinodermata

**Class:** Echinoidea

|    | **Morphology** |
|:-- | :------------: |
| B  |  |
| δB |  |
| W  |  |
| δW |  |
|    | **Flagellum** |
| L  |  |
| δL |  |
| λ  |  |
| δλ |  |
| h  |  |
| δh |  |
|    | **Kinematics** |
| U  | 243 |
| δU | 15 |
| f  | 45.8 |
| δf | 4.6 |
| Ω  | 4.8 |
| δΩ | 0.8 |

**Notes:**

1.

**References:**

1. Hiramoto Y, Baba S.  Quantitative analysis of flagellar movement in echinoderm spermatozoa.  J Exp Biol.1978;76:85–104.
