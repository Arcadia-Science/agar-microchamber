**Species:** *Gallus domesticus-Domestic fowl*

![alt text](https://github.com/marcos-fvr/BOSO-micro/blob/main/9-Figures/Rooster_spermatozoon.png)

**Phylum:** Chordata

**Class:** Aves

|    | **Morphology** |
|:-- | :------------: |
| B  |  |
| δB |  |
| W  |  |
| δW |  |
|    | **Flagellum** |
| L  | 82 |
| δL |  |
| λ  | 24.6 |
| δλ | 3.6 |
| h  | 5.9 |
| δh | 1.5 |
|    | **Kinematics** |
| U  | 66.5 |
| δU | 10.1 |
| f  | 25.4 |
| δf | 4.8 |
| Ω  | 14.8 |
| δΩ | 2.9 |

**Notes:**

1.

**References:**

1. Vernon GG, Woolley DM.  Three-dimensional motion of avian Spermatozoa.  Cell Motil Cytosk. 1999;42:149–161.
