**Species:** *Silurus glanis-Wels catfish*

**Phylum:** Chordata

**Class:** Actinopterygii

|    | **Morphology** |
|:-- | :------------: |
| B  |  |
| δB |  |
| W  |  |
| δW |  |
|    | **Flagellum** |
| L  |  |
| δL |  |
| λ  |  |
| δλ |  |
| h  |  |
| δh |  |
|    | **Kinematics** |
| U  | 130 |
| δU |  |
| f  | 35 |
| δf |  |
| Ω  |  |
| δΩ |  |

**Notes:**

1.

**References:**

1. Cosson J.  Frenetic activation of fish spermatozoa flagella entails short-term motility, portending their precocious decadence.  J Fish Biolog. 2010;76:240–279.
