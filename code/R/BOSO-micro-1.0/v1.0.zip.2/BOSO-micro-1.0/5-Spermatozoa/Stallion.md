**Species:** *Stallion*

**Phylum:** Chordata

**Class:** Mammalia

|    | **Morphology** |
|:-- | :------------: |
| B  | 5.975 |
| δB | 0.645 |
| W  | 3.025 |
| δW | 0.235 |
|    | **Flagellum** |
| L  | 48.75 |
| δL | 8.25 |
| λ  |  |
| δλ |  |
| h  |  |
| δh |  |
|    | **Kinematics** |
| U  | 86.7 |
| δU | 3.8 |
| f  |  |
| δf |  |
| Ω  |  |
| δΩ |  |

**Notes:**

1.

**References:**

1. Yamane J, Ito T. Über die Geschwindigkeit der Pferdespermatozoen in strömenden und nichtströmenden Flüssigkeiten.  Cytologia. 1932;3:188–199.
1. Brito L.  Evaluation of Stallion sperm morphology.  Clin Tech Equine Pract. 2007;6:249–264.
