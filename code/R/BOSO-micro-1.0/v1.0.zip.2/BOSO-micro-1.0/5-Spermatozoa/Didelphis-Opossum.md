**Species:** *Didelphis-Opossum*

**Phylum:** Chordata

**Class:** Mammalia

|    | **Morphology** |
|:-- | :------------: |
| B  |  |
| δB |  |
| W  |  |
| δW |  |
|    | **Flagellum** |
| L  |  |
| δL |  |
| λ  |  |
| δλ |  |
| h  |  |
| δh |  |
|    | **Kinematics** |
| U  |  |
| δU |  |
| f  |  |
| δf |  |
| Ω  |  |
| δΩ |  |

**Notes:**

1.

**References:**

1. Phillips DM.  Comparative analysis of mammalian sperm motility.  J Cell Biol. 1972;53:561–73.
1. Holfstein AF.  Elektronenmikroskopische Untersuchungen am Spermatozoon des Opossums (*Didelphys virginiana* Kerr).  Z Zellforsch Mikrosk Anat. 1965;65:905–914.
