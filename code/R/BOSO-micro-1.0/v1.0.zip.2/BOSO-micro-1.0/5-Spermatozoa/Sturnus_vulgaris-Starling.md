**Species:** *Sturnus vulgaris-Starling*

**Phylum:** Chordata

**Class:** Aves

|    | **Morphology** |
|:-- | :------------: |
| B  | 10.3 |
| δB |  |
| W  |  |
| δW |  |
|    | **Flagellum** |
| L  | 73.4 |
| δL |  |
| λ  |  |
| δλ |  |
| h  |  |
| δh |  |
|    | **Kinematics** |
| U  | 155 |
| δU | 45 |
| f  | 66 |
| δf | 24 |
| Ω  | 30 |
| δΩ |  |

**Notes:**

1.

**References:**

1. Vernon GG, Woolley DM.  Three-dimensional motion of avian Spermatozoa.  Cell Motil Cytosk. 1999;42:149–161.
