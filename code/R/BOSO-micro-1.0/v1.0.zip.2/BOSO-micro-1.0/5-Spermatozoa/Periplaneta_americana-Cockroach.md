**Species:** *Periplaneta americana-Cockroach*

**Phylum:** Arthropoda

**Class:** Insecta

|    | **Morphology** |
|:-- | :------------: |
| B  | 14.85 |
| δB |  |
| W  | 0.95 |
| δW |  |
|    | **Flagellum** |
| L  | 57.75 |
| δL |  |
| λ  |  |
| δλ |  |
| h  | 6.43 |
| δh |  |
|    | **Kinematics** |
| U  | 35.79 |
| δU | 18.47 |
| f  |  |
| δf |  |
| Ω  |  |
| δΩ |  |

**Notes:**

1.

**References:**

1. Richards AG. The rate of sperm locomotion in the cockroach as a function of temperature. J Ins Physiol.1963;9:545–549.
1. Linley JR.  Activity and motility of spermatozoa of *Culicoides melleus* (Diptera:  Ceratopogonidae).  Ent Exp Appl.1979;26:85–96.
1. Breland OP, Eddleman CD, Biesele JJ.  Studies of insect spermatozoa I.  Entomol News. 1968;79:197–216.
