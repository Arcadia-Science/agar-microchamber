**Species:** *Carassius auratus-Goldfish*

**Phylum:** Chordata

**Class:** Actinopterygii

|    | **Morphology** |
|:-- | :------------: |
| B  | 4.2 |
| δB | 0.06 |
| W  | 4.3 |
| δW | 0.06 |
|    | **Flagellum** |
| L  | 41.6 |
| δL | 11.3 |
| λ  |  |
| δλ |  |
| h  |  |
| δh |  |
|    | **Kinematics** |
| U  | 109.4 |
| δU | 9.8 |
| f  |  |
| δf |  |
| Ω  |  |
| δΩ |  |

**Notes:**

1.

**References:**

1. Van Look KJW, Kime DE.  Automated sperm morphology analysis in fishes:  the effect of mercury on goldfish sperm. J Fish Biol. 2003;63:1020–1033.
