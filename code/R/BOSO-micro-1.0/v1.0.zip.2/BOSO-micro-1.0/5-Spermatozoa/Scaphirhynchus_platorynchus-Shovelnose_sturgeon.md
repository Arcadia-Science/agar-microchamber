**Species:** *Scaphirhynchus platorynchus-Shovelnose sturgeon*

**Phylum:** Chordata

**Class:** Actinopterygii

|    | **Morphology** |
|:-- | :------------: |
| B  |  |
| δB |  |
| W  |  |
| δW |  |
|    | **Flagellum** |
| L  |  |
| δL |  |
| λ  |  |
| δλ |  |
| h  |  |
| δh |  |
|    | **Kinematics** |
| U  | 200 |
| δU |  |
| f  | 49 |
| δf | 1 |
| Ω  |  |
| δΩ |  |

**Notes:**

1.

**References:**

1. Cosson J.  Frenetic activation of fish spermatozoa flagella entails short-term motility, portending their precocious decadence.  J Fish Biolog. 2010;76:240–279.
