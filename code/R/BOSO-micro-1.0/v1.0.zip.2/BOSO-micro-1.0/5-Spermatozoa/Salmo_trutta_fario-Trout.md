**Species:** *Salmo trutta fario-Trout*

**Phylum:** Chordata

**Class:** Actinopterygii

|    | **Morphology** |
|:-- | :------------: |
| B  |  |
| δB |  |
| W  |  |
| δW |  |
|    | **Flagellum** |
| L  |  |
| δL |  |
| λ  |  |
| δλ |  |
| h  |  |
| δh |  |
|    | **Kinematics** |
| U  | 162 |
| δU | 2 |
| f  |  |
| δf |  |
| Ω  |  |
| δΩ |  |

**Notes:**

1.

**References:**

1. Alavi SMH, Cosson J.  Sperm motility in fishes. I. Effects of temperature and pH: a review.  Cell Biolog Intl. 2005;29:101–110.
