**Species:** *Columba livia-Pigeon*

**Phylum:** Chordata

**Class:** Aves

|    | **Morphology** |
|:-- | :------------: |
| B  | 16 |
| δB |  |
| W  |  |
| δW |  |
|    | **Flagellum** |
| L  | 132 |
| δL | 11.1 |
| λ  |  |
| δλ |  |
| h  |  |
| δh |  |
|    | **Kinematics** |
| U  |  |
| δU |  |
| f  |  |
| δf |  |
| Ω  |  |
| δΩ |  |

**Notes:**

1.

**References:**

1. Vernon GG, Woolley DM.  Three-dimensional motion of avian Spermatozoa.  Cell Motil Cytosk. 1999;42:149–161.
