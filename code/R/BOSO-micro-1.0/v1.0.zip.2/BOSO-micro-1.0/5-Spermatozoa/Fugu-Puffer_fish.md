**Species:** *Fugu-Puffer fish*

**Phylum:** Chordata

**Class:** Actinopterygii

|    | **Morphology** |
|:-- | :------------: |
| B  |  |
| δB |  |
| W  |  |
| δW |  |
|    | **Flagellum** |
| L  |  |
| δL |  |
| λ  |  |
| δλ |  |
| h  |  |
| δh |  |
|    | **Kinematics** |
| U  | 160 |
| δU |  |
| f  |  |
| δf |  |
| Ω  |  |
| δΩ |  |

**Notes:**

1.

**References:**

1. Cosson J, Groison AL, Suquet M, Fauvel C, Dreanno C, Billard R.  Marine fish spermatozoa:  racing ephemeral swimmers.  Reproduction. 2008;136:277–294.
