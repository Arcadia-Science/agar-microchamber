**Species:** *Taeniopygia guttata-Zebra finch*

**Phylum:** Chordata

**Class:** Aves

|    | **Morphology** |
|:-- | :------------: |
| B  | 11.3 |
| δB | 1 |
| W  |  |
| δW |  |
|    | **Flagellum** |
| L  | 64.1 |
| δL | 5.7 |
| λ  |  |
| δλ |  |
| h  |  |
| δh |  |
|    | **Kinematics** |
| U  |  |
| δU |  |
| f  |  |
| δf |  |
| Ω  |  |
| δΩ |  |

**Notes:**

1.

**References:**

1. Vernon GG, Woolley DM.  Three-dimensional motion of avian Spermatozoa.  Cell Motil Cytosk. 1999;42:149–161.
