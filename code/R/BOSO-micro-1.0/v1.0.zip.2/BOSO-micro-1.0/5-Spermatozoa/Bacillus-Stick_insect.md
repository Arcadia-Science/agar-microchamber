**Species:** *Bacillus-Stick insect*

**Phylum:** Arthropoda

**Class:** Insecta

|    | **Morphology** |
|:-- | :------------: |
| B  |  |
| δB |  |
| W  |  |
| δW |  |
|    | **Flagellum** |
| L  |  |
| δL |  |
| λ  | 18 |
| δλ | 12 |
| h  | 9 |
| δh | 6 |
|    | **Kinematics** |
| U  | 58 |
| δU | 42 |
| f  | 14.45 |
| δf | 13.55 |
| Ω  |  |
| δΩ |  |

**Notes:**

1.

**References:**

1. Bacetti B, *et al*.  Motility patterns in sperms with different tail structure.  In:  Afzelius BA, editor. The Functional Anatomy of the Spermatozoon. Pergamon; 1975. p. 141–150.
