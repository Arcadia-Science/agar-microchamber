**Species:** *Selenomonas ruminantium*

**Phylum:** Firmicutes

**Class:** Clostridia

|    | **Morphology** |
|:-- | :------------: |
| B  | 3.98 |
| δB |  |
| W  | 1.17 |
| δW |  |
|    | **Flagella** |
| N  | 6 |
| δN | 1.4 |
| L  |  |
| δL |  |
| λ  | 4.77 |
| δλ | 0.07 |
| h  | 0.9475 |
| δh | 0.0175 |
|    | **Kinematics** |
| U  | 16 |
| δU | 6 |
| f  |  |
| δf |  |
| Ω  |  |
| δΩ |  |

**Notes:**

1.

**References:**

1. Haya S, Tokumaru Y, Abe N, Kaneko J, ichi Aizawa S.  Characterization of Lateral Flagella of *Selenomonas ruminantium*.  Appl Envir Microbiol. 2011;77:2799–2802.
