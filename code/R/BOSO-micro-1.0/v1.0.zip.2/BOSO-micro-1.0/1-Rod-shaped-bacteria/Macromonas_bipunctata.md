**Species:** *Macromonas bipunctata*

**Phylum:** Proteobacteria

**Class:** Betaproteobacteria

|    | **Morphology** |
|:-- | :------------: |
| B  | 10 |
| δB | 2 |
| W  | 4 |
| δW | 1 |
|    | **Flagella** |
| N  | 1 |
| δN |  |
| L  | 12.5 |
| δL | 2.5 |
| λ  |  |
| δλ |  |
| h  |  |
| δh |  |
|    | **Kinematics** |
| U  | 10 |
| δU |  |
| f  |  |
| δf |  |
| Ω  |  |
| δΩ |  |

**Notes:**

1.

**References:**

1. Breed RS, Murray EGD, Smith NR.  Bergey’s manual of determinative bacteriology.  Baltimore:  Williams & Wilkins;1957.
1. Garrity GM, Brenner DJ, Krieg NR, Staley JT.  Bergey’s manual of systematic bacteriology. II. The Proteobacteria. Part B: The Gammaproteobacteria.  New York:  Springer; 2005.
