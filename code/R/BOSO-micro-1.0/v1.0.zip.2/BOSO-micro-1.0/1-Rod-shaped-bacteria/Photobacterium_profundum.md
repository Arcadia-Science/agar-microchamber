**Species:** *Photobacterium profundum*

**Phylum:** Proteobacteria

**Class:** Gammaproteobacteria

|    | **Morphology** |
|:-- | :------------: |
| B  | 2.94 |
| δB |  |
| W  | 1.76 |
| δW |  |
|    | **Flagella** |
| N  | 1 |
| δN |  |
| L  | 9 |
| δL |  |
| λ  | 2.22 |
| δλ |  |
| h  | 0.39 |
| δh |  |
|    | **Kinematics** |
| U  | 27 |
| δU | 1.2 |
| f  |  |
| δf |  |
| Ω  |  |
| δΩ |  |

**Notes:**

1.

**References:**

1. Eloe EA, Lauro FM, Vogel RF, Bartlett DH.  The Deep-Sea Bacterium *Photobacterium profundum* SS9 Utilizes Separate Flagellar Systems for Swimming and Swarming under High-Pressure Conditions.  Appl Envir Microbiol.2008;74:6298–6305.
