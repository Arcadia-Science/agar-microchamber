**Species:** *Candidatus Ovobacter propellens*

**Phylum:** -

**Class:** -

|    | **Morphology** |
|:-- | :------------: |
| B  | 4.5 |
| δB | 0.5 |
| W  |  |
| δW |  |
|    | **Flagella** |
| N  | 400 |
| δN |  |
| L  |  |
| δL |  |
| λ  |  |
| δλ |  |
| h  |  |
| δh |  |
|    | **Kinematics** |
| U  | 800 |
| δU | 200 |
| f  | 150 |
| δf | 50 |
| Ω  | 75 |
| δΩ | 25 |

**Notes:**

1.

**References:**

1. Fenchel T, Thar R. *Candidatus Ovobacter propellens*: a large conspicuous prokaryote with an unusual motility behaviour. FEMS Microbiol Ecol. 2004;48(2):231–238.
