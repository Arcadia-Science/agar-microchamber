**Species:** *Photobacterium phosphoreum*

**Phylum:** Proteobacteria

**Class:** Gammaproteobacteria

|    | **Morphology** |
|:-- | :------------: |
| B  | 1.2 |
| δB |  |
| W  |  |
| δW |  |
|    | **Flagella** |
| N  | 1 |
| δN |  |
| L  |  |
| δL |  |
| λ  | 3.1 |
| δλ |  |
| h  | 0.37 |
| δh |  |
|    | **Kinematics** |
| U  |  |
| δU |  |
| f  |  |
| δf |  |
| Ω  |  |
| δΩ |  |

**Notes:**

1.

**References:**

1. Breed RS, Murray EGD, Smith NR.  Bergey’s manual of determinative bacteriology.  Baltimore:  Williams & Wilkins;1957.
1. Leifson E.  Atlas of Bacterial Flagellation.  New York:  Academic; 1960.
