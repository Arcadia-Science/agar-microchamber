**Species:** *Listeria monocytogenes*

**Phylum:** Firmicutes

**Class:** Bacilli

|    | **Morphology** |
|:-- | :------------: |
| B  | 1.5 |
| δB | 0.5 |
| W  |  |
| δW |  |
|    | **Flagella** |
| N  |  |
| δN |  |
| L  |  |
| δL |  |
| λ  |  |
| δλ |  |
| h  |  |
| δh |  |
|    | **Kinematics** |
| U  | 0.113 |
| δU | 0.05 |
| f  |  |
| δf |  |
| Ω  |  |
| δΩ |  |

**Notes:**

1.

**References:**

1. Giardini P, Theriot J.  Effects of intermediate filaments on actin-based motility of *Listeria monocytogenes*.  Biophys J.2001;81(6):3193–3203
