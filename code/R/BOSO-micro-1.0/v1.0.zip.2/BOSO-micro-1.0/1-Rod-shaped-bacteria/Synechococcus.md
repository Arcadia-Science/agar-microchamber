**Species:** *Synechococcus*

![alt text](https://github.com/marcos-fvr/BOSO-micro/blob/main/9-Figures/Synechococcus_sp.png)

**Phylum:** Cyanobacteria

**Class:** Synechococcales

|    | **Morphology** |
|:-- | :------------: |
| B  | 2 |
| δB |  |
| W  | 1 |
| δW |  |
|    | **Flagella** |
| N  |  |
| δN |  |
| L  |  |
| δL |  |
| λ  |  |
| δλ |  |
| h  |  |
| δh |  |
|    | **Kinematics** |
| U  | 15 |
| δU | 10 |
| f  |  |
| δf |  |
| Ω  | 1 |
| δΩ |  |

**Notes:**

1.

**References:**

1. Ehlers K, Samuel A, Berg H, Montgomery R.  Do cyanobacteria swim using traveling surface waves? Proc Natl AcadSci USA. 1996 Aug 6;93(16):8340–8343.
1. Ehlers K, Oster G.  On the mysterious propulsion of *Synechococcus*.  PLOS ONE. 2012;7(5).
