**Species:** *Macromonas mobilis*

![alt text](https://github.com/marcos-fvr/BOSO-micro/blob/main/9-Figures/Macromonas_sp.png)

**Phylum:** Proteobacteria

**Class:** Betaproteobacteria

|    | **Morphology** |
|:-- | :------------: |
| B  | 21 |
| δB | 9 |
| W  | 11 |
| δW | 3 |
|    | **Flagella** |
| N  | 1 |
| δN |  |
| L  | 30 |
| δL | 10 |
| λ  |  |
| δλ |  |
| h  |  |
| δh |  |
|    | **Kinematics** |
| U  | 13.3 |
| δU |  |
| f  |  |
| δf |  |
| Ω  |  |
| δΩ |  |

**Notes:**

1.

**References:**

1. Breed RS, Murray EGD, Smith NR.  Bergey’s manual of determinative bacteriology.  Baltimore:  Williams & Wilkins;1957.
1. Garrity GM, Brenner DJ, Krieg NR, Staley JT.  Bergey’s manual of systematic bacteriology. II. The Proteobacteria. Part B: The Gammaproteobacteria.  New York:  Springer; 2005.
