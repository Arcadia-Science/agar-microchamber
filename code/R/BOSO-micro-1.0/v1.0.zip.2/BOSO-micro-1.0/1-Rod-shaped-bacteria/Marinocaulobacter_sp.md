**Species:** *Marinocaulobacter sp*

**Phylum:** Proteobacteria

**Class:** Alphaproteobacteria

|    | **Morphology** |
|:-- | :------------: |
| B  |  |
| δB |  |
| W  |  |
| δW |  |
|    | **Flagella** |
| N  |  |
| δN |  |
| L  |  |
| δL |  |
| λ  |  |
| δλ |  |
| h  |  |
| δh |  |
|    | **Kinematics** |
| U  | 12.95 |
| δU | 1.65 |
| f  |  |
| δf |  |
| Ω  |  |
| δΩ |  |

**Notes:**

1.

**References:**

1. Johansen J, Pinhassi J, Blackburn N, Zweifel U, Hagström A.  Variability in motility characteristics among marine bacteria.  Aquat Microb Ecol. 2002 07;28:229–237.
