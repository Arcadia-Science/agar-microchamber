**Species:** *Marine bacterium TW-3 AY028198*

**Phylum:** Proteobacteria

**Class:** Gammaproteobacteria

|    | **Morphology** |
|:-- | :------------: |
| B  | 2 |
| δB |  |
| W  | 0.8 |
| δW |  |
|    | **Flagella** |
| N  |  |
| δN |  |
| L  |  |
| δL |  |
| λ  |  |
| δλ |  |
| h  |  |
| δh |  |
|    | **Kinematics** |
| U  | 49.5 |
| δU | 6.5 |
| f  |  |
| δf |  |
| Ω  |  |
| δΩ |  |

**Notes:**

1.

**References:**

1. Kiørboe T, Grossart HP, Ploug H, Tang K.  Mechanisms and Rates of Bacterial Colonization of Sinking Aggregates. Applied and Environmental Microbiology. 2002;68(8):3996–4006.
1. Visser AW, Kiørboe T.  Plankton motility patterns and encounter rates.  Oecologia. 2006;148:538–546.
