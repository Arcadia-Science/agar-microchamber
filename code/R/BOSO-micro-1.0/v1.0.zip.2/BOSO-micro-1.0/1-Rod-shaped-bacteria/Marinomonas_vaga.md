**Species:** *Marinomonas vaga*

**Phylum:** Proteobacteria

**Class:** Gammaproteobacteria

|    | **Morphology** |
|:-- | :------------: |
| B  |  |
| δB |  |
| W  | 0.375 |
| δW | 0.035 |
|    | **Flagella** |
| N  |  |
| δN |  |
| L  |  |
| δL |  |
| λ  |  |
| δλ |  |
| h  |  |
| δh |  |
|    | **Kinematics** |
| U  | 22.9 |
| δU | 0.6 |
| f  |  |
| δf |  |
| Ω  |  |
| δΩ |  |

**Notes:**

1.

**References:**

1. Johansen J, Pinhassi J, Blackburn N, Zweifel U, Hagström A.  Variability in motility characteristics among marine bacteria.  Aquat Microb Ecol. 2002 07;28:229–237.
