**Species:** *Vibrio splendidus*

**Phylum:** Proteobacteria

**Class:** Gammaproteobacteria

|    | **Morphology** |
|:-- | :------------: |
| B  |  |
| δB |  |
| W  | 0.26 |
| δW |  |
|    | **Flagella** |
| N  |  |
| δN |  |
| L  |  |
| δL |  |
| λ  |  |
| δλ |  |
| h  |  |
| δh |  |
|    | **Kinematics** |
| U  | 19.4 |
| δU |  |
| f  |  |
| δf |  |
| Ω  |  |
| δΩ |  |

**Notes:**

1.

**References:**

1. Johansen J, Pinhassi J, Blackburn N, Zweifel U, Hagström A.  Variability in motility characteristics among marine bacteria.  Aquat Microb Ecol. 2002 07;28:229–237.
