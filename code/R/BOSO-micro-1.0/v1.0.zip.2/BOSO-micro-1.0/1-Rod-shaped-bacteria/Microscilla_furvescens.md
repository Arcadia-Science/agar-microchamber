**Species:** *Microscilla furvescens*

**Phylum:** Bacteroidetes

**Class:** Cytophagia

|    | **Morphology** |
|:-- | :------------: |
| B  | 3.5 |
| δB |  |
| W  | 1 |
| δW |  |
|    | **Flagella** |
| N  |  |
| δN |  |
| L  |  |
| δL |  |
| λ  |  |
| δλ |  |
| h  |  |
| δh |  |
|    | **Kinematics** |
| U  | 41.5 |
| δU | 9.5 |
| f  |  |
| δf |  |
| Ω  |  |
| δΩ |  |

**Notes:**

1.

**References:**

1. Kiørboe T, Grossart HP, Ploug H, Tang K.  Mechanisms and Rates of Bacterial Colonization of Sinking Aggregates. Applied and Environmental Microbiology. 2002;68(8):3996–4006.
