**Species:** *Bradyrhizobium japonicum*

**Phylum:** Proteobacteria

**Class:** Alphaproteobacteria

|    | **Morphology** |
|:-- | :------------: |
| B  | 1.68 |
| δB | 0.06 |
| W  | 0.675 |
| δW | 0.055 |
|    | **Flagella** |
| N  | 1 |
| δN |  |
| L  |  |
| δL |  |
| λ  | 1.88 |
| δλ | 1.22 |
| h  |  |
| δh |  |
|    | **Kinematics** |
| U  | 30.4 |
| δU | 5.7 |
| f  |  |
| δf |  |
| Ω  |  |
| δΩ |  |

**Notes:**

1.

**References:**

1. Kanbe M, Yagasaki J, Zehner S, Göttfert M, Aizawa SI.  Characterization of Two Sets of Subpolar Flagella in *Bradyrhizobium japonicum*.  J Bacteriol. 2007;189:1083–1089.
