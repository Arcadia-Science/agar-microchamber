**Species:** *Haloarcula quadrata*

**Phylum:** Euryarchaeota

**Class:** Halobacteria

|    | **Morphology** |
|:-- | :------------: |
| B  | 2.715 |
| δB | 0.355 |
| W  |  |
| δW |  |
|    | **Flagella** |
| N  |  |
| δN |  |
| L  | 5.18 |
| δL |  |
| λ  | 1.315 |
| δλ | 0.435 |
| h  | 0.13 |
| δh | 0.02 |
|    | **Kinematics** |
| U  | 0.73 |
| δU | 0.29 |
| f  |  |
| δf |  |
| Ω  |  |
| δΩ |  |

**Notes:**

1.

**References:**

1. Alam M, Claviez M, Oesterhelt D, Kessell M.  Flagella and motility behaviour of square bacteria.  EMBO J.1984;3:2899–2903.
