**Species:** *Genus species*

**Phylum:** Spirochaetes

**Order:** Taxonomic order

|     | **Morphology** |
|:--- | :------------: |
| B   |  |
| δB  |  |
| W   |  |
| δW  |  |
| λb  |  |
| δλb |  |
| hb  |  |
| δhb |  |
|     | **Endoflagella** |
| N   |  |
| δN  |  |
|     | **Kinematics** |
| U   |  |
| δU  |  |
| f   |  |
| δf  |  |

**Notes:**

1. **λb:** Wavelength of spiral body;
1. **hb:** Radius of spiral body;

**References:**

1.
