**Species:** *Genus species*

**Phylum:** Phylum name

**Class:** Taxonomic class

|      | **Morphology** |
| :--- | :------------: |
| B    |  |
| δB   |  |
| W    |  |
| δW   |  |
|      | **Cilia** |
| N    |  |
| δN   |  |
| L    |  |
| δL   |  |
| d    |  |
| δd   |  |
| κ    |  |
| δκ   |  |
|      | **Kinematics** |
| U    |  |
| δU   |  |
| f    |  |
| δf   |  |
| λmw  |  |
| δλmw |  |

**Notes:**

1. **λmw:** Wavelength of metachronal waves;

**References:**

1.
