**Species:** *Spiroplasma species*

**Phylum:** Tenericutes

**Class:** Mollicutes

|     | **Morphology** |
|:--- | :------------: |
| B   |  |
| δB  |  |
| W   |  |
| δW  |  |
| λb  |  |
| δλb |  |
| hb  |  |
| δhb |  |
|     | **Kinematics** |
| U   |  |
| δU  |  |
| ck  |  |
| δck |  |

**Notes:**

1. **λb:** Wavelength of spiral body;
1. **hb:** Radius of spiral body;
1. **ck:** Speed of the propagation of kinks [µm s-1]

**References:**

1.
