**Species:** *Genus species*

**Phylum:** Phylum name

**Class:** Taxonomic class

|     | **Morphology** |
|:--- | :------------: |
| B   |  |
| δB  |  |
| W   |  |
| δW  |  |
| λb  |  |
| δλb |  |
| hb  |  |
| δhb |  |
|     | **Flagella** |
| N   |  |
| δN  |  |
| L   |  |
| δL  |  |
| λ   |  |
| δλ  |  |
| h   |  |
| δh  |  |
|     | **Kinematics** |
| U   |  |
| δU  |  |
| f   |  |
| δf  |  |
| Ω   |  |
| δΩ  |  |

**Notes:**

1. **λb:** Wavelength of spiral body;
1. **hb:** Radius of spiral body;

**References:**

1.
