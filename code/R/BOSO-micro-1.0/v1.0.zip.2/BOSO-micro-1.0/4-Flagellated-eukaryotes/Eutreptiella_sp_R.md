**Species:** *Eutreptiella sp R*

**Phylum:** Euglenozoa

**Class:** Euglenida

|    | **Morphology** |
|:-- | :------------: |
| B  | 50 |
| δB | 10 |
| W  | 15 |
| δW | 2 |
|    | **Flagella** |
| N  |  |
| δN |  |
| L  |  |
| δL |  |
| λ  |  |
| δλ |  |
| h  |  |
| δh |  |
|    | **Kinematics** |
| U  | 135 |
| δU | 20 |
| f  |  |
| δf |  |
| Ω  |  |
| δΩ |  |

**Notes:**

1.

**References:**

1. Throndsen J.  Motility in some marine nanoplankton flagellates.  Norw J Zool. 1973;21:193–200.
1. Olenina I, *et al*.  Biovolumes and Size-Classes of Phytoplankton in the Baltic Sea.  Balt Sea Environ Proc. 2006;106:144.
