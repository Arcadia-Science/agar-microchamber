**Species:** *Pseudoscourfieldia marina*

**Phylum:** Chlorophyta

**Class:** Pyramimonadophyceae

|    | **Morphology** |
|:-- | :------------: |
| B  | 4.1 |
| δB | 0.9 |
| W  |  |
| δW |  |
|    | **Flagella** |
| N  |  |
| δN |  |
| L  |  |
| δL |  |
| λ  |  |
| δλ |  |
| h  |  |
| δh |  |
|    | **Kinematics** |
| U  | 42 |
| δU | 21 |
| f  |  |
| δf |  |
| Ω  |  |
| δΩ |  |

**Notes:**

1.

**References:**

1. Bauerfeind E, Elbrächter M, Steiner R, Throndsen J.  Application of Laser Doppler Spectroscopy (LDS) indetermining swimming velocities of motile phytoplankton.  Marine Biology. 1986;93:323–327.
