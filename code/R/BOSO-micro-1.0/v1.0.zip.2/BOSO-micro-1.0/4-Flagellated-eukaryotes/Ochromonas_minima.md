**Species:** *Ochromonas minima*

**Phylum:** Ochrophyta (Heterokont)

**Class:** Chrysophyceae

|    | **Morphology** |
|:-- | :------------: |
| B  | 5 |
| δB | 1.5 |
| W  |  |
| δW |  |
|    | **Flagella** |
| N  | 2 |
| δN |  |
| L  | 1.5 |
| δL | 0.5 |
| λ  |  |
| δλ |  |
| h  |  |
| δh |  |
|    | **Kinematics** |
| U  | 75 |
| δU |  |
| f  |  |
| δf |  |
| Ω  |  |
| δΩ |  |

**Notes:**

1.

**References:**

1. Throndsen J.  Motility in some marine nanoplankton flagellates.  Norw J Zool. 1973;21:193–200.
1. 249. Tomas CR. Marine Phytoplankton:  A Guide to Naked Flagellates and Coccolithophorids. London: Academic; 1993.
