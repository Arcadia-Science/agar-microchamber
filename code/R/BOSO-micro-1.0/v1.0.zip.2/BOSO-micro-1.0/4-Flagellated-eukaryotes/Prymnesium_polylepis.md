**Species:** *Prymnesium polylepis*

**Phylum:** Haptophyta

**Class:** Prymnesiophyceae

|    | **Morphology** |
|:-- | :------------: |
| B  | 9.1 |
| δB | 0.8 |
| W  | 6.8 |
| δW | 0.4 |
|    | **Flagella** |
| N  | 2 |
| δN |  |
| L  | 28 |
| δL |  |
| λ  | 13.4 |
| δλ | 2.4 |
| h  | 2.15 |
| δh | 0.25 |
|    | **Kinematics** |
| U  | 45 |
| δU |  |
| f  | 33.3 |
| δf |  |
| Ω  |  |
| δΩ |  |

**Notes:**

1.

**References:**

1. Dölger J, Nielsen LT, Kiørboe T, Andersen A.  Swimming and feeding of mixotrophic biflagellates.  Sci Rep.2017;7:39892.
