**Species:** *Protoperidinium pacificum*

**Phylum:** Dinoflagellata

**Class:** Dinophyceae

|    | **Morphology** |
|:-- | :------------: |
| B  | 54 |
| δB |  |
| W  | 50 |
| δW |  |
|    | **Flagella** |
| N  |  |
| δN |  |
| L  |  |
| δL |  |
| λ  |  |
| δλ |  |
| h  |  |
| δh |  |
|    | **Kinematics** |
| U  | 410 |
| δU |  |
| f  |  |
| δf |  |
| Ω  |  |
| δΩ |  |

**Notes:**

1.

**References:**

1. Buskey EJ, Coulter C, Strom S.  Locomotory Patterns of Microzooplankton:  Potential Effects on Food Selectivity of Larval Fish. Bull Marine Science. 1993;53:29–43.
