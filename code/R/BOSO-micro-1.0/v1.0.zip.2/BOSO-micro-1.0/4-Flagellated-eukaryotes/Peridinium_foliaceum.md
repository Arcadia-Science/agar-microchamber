**Species:** *Peridinium foliaceum*

**Phylum:** Dinoflagellata

**Class:** Dinophyceae

|    | **Morphology** |
|:-- | :------------: |
| B  | 30.6 |
| δB | 3.3 |
| W  | 30.6 |
| δW | 3.3 |
|    | **Flagella** |
| N  |  |
| δN |  |
| L  |  |
| δL |  |
| λ  |  |
| δλ |  |
| h  |  |
| δh |  |
|    | **Kinematics** |
| U  | 185.2 |
| δU |  |
| f  |  |
| δf |  |
| Ω  | 2 |
| δΩ |  |

**Notes:**

1.

**References:**

1. Kamykowski D, Reed RE, Kirkpatrick GJ.  Comparison of sinking velocity, swimming velocity, rotation and path characteristics among six marine dinoflagellate species.  Marine Biology. 1992;113:319–328.
