**Species:** *Distigma sp*

**Phylum:** Euglenozoa

**Class:** Euglenida (Aphagea)

|    | **Morphology** |
|:-- | :------------: |
| B  | 74.8 |
| δB | 31 |
| W  |  |
| δW |  |
|    | **Flagella** |
| N  | 2 |
| δN |  |
| L  | 93.5 |
| δL | 56.1 |
| λ  |  |
| δλ |  |
| h  |  |
| δh |  |
|    | **Kinematics** |
| U  |  |
| δU |  |
| f  |  |
| δf |  |
| Ω  |  |
| δΩ |  |

**Notes:**

1.

**References:**

1. Lowndes AG.  On flagellar movement in unicellular organisms.  Proc Zool Soc London. 1941;111A:111–134.
1. Kent WS.  A manual of the infusoria.  Repressed; 1880.
