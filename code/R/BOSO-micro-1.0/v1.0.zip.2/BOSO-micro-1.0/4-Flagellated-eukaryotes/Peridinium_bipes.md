**Species:** *Peridinium bipes*

**Phylum:** Dinoflagellata

**Class:** Dinophyceae

|    | **Morphology** |
|:-- | :------------: |
| B  | 42.9 |
| δB |  |
| W  | 37 |
| δW |  |
|    | **Flagella** |
| N  |  |
| δN |  |
| L  |  |
| δL |  |
| λ  |  |
| δλ |  |
| h  |  |
| δh |  |
|    | **Kinematics** |
| U  | 291 |
| δU |  |
| f  |  |
| δf |  |
| Ω  | 4.99 |
| δΩ |  |

**Notes:**

1.

**References:**

1. Fenchel T.  How dinoflagellates swim.  Protist. 2001;152:329–338.
