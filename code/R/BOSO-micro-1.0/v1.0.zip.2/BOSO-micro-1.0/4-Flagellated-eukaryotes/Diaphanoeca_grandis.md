**Species:** *Diaphanoeca grandis*

**Phylum:** Choanoflagellida (Opisthokonta)

**Class:** Choanoflagellatea

|    | **Morphology** |
|:-- | :------------: |
| B  |  |
| δB |  |
| W  |  |
| δW |  |
|    | **Flagella** |
| N  |  |
| δN |  |
| L  |  |
| δL |  |
| λ  |  |
| δλ |  |
| h  |  |
| δh |  |
|    | **Kinematics** |
| U  | 80 |
| δU |  |
| f  |  |
| δf |  |
| Ω  |  |
| δΩ |  |

**Notes:**

1.

**References:**

1. Hansen PJ, Bjørnsen PK, Hansen BW.  Zooplankton grazing and growth:  Scaling within the 2-2,000-μm body sizerange.  Limnology and Oceanography. 1997;42(4):687–704.
