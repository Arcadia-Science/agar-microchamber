**Species:** *Apedinella spinifera*

**Phylum:** Ochrophyta (Heterokont)

**Class:** Dictyochophyceae

|    | **Morphology** |
|:-- | :------------: |
| B  | 8.25 |
| δB | 1.75 |
| W  |  |
| δW |  |
|    | **Flagella** |
| N  |  |
| δN |  |
| L  | 13.25 |
| δL | 6.75 |
| λ  |  |
| δλ |  |
| h  |  |
| δh |  |
|    | **Kinematics** |
| U  | 132.5 |
| δU | 42.5 |
| f  |  |
| δf |  |
| Ω  |  |
| δΩ |  |

**Notes:**

1.

**References:**

1. Throndsen J.  Motility in some marine nanoplankton flagellates.  Norw J Zool. 1973;21:193–200.
1. 249. Tomas CR. Marine Phytoplankton:  A Guide to Naked Flagellates and Coccolithophorids. London: Academic; 1993.
