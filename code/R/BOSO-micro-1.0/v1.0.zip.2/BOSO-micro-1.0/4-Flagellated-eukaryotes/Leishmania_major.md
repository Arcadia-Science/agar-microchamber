**Species:** *Leishmania major*

**Phylum:** Euglenozoa

**Class:** Kinetoplastea

|    | **Morphology** |
|:-- | :------------: |
| B  | 12.5 |
| δB | 0.3 |
| W  |  |
| δW |  |
|    | **Flagella** |
| N  | 1 |
| δN |  |
| L  | 16.4 |
| δL | 0.6 |
| λ  | 11.9 |
| δλ | 0.3 |
| h  | 2.9 |
| δh | 0.07 |
|    | **Kinematics** |
| U  | 36.4 |
| δU | 2 |
| f  | 24.5 |
| δf | 0.8 |
| Ω  |  |
| δΩ |  |

**Notes:**

1.

**References:**

1. Gadelha C, Wickstead B, Gul K.  Flagellar and Ciliary Beating in Trypanosome Motility.  Cell Motil Cytosk.2007;64:629–643.
