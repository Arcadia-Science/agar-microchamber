**Species:** *Poteriodendron sp*

**Phylum:** Bygira (Heterokont)

**Class:** Bicosoecida

|    | **Morphology** |
|:-- | :------------: |
| B  |  |
| δB |  |
| W  |  |
| δW |  |
|    | **Flagella** |
| N  |  |
| δN |  |
| L  | 35 |
| δL |  |
| λ  | 4 |
| δλ |  |
| h  | 2 |
| δh |  |
|    | **Kinematics** |
| U  |  |
| δU |  |
| f  | 40 |
| δf |  |
| Ω  |  |
| δΩ |  |

**Notes:**

1.

**References:**

1. Sleigh MA.  Cilia and Flagella.  London:  Academic; 1962.
