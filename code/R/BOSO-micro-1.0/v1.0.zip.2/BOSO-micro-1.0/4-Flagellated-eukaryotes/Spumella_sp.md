**Species:** *Spumella sp*

**Phylum:** Ochrophyta (Heterokont)

**Class:** Chrysophyceae

|    | **Morphology** |
|:-- | :------------: |
| B  | 10 |
| δB |  |
| W  |  |
| δW |  |
|    | **Flagella** |
| N  |  |
| δN |  |
| L  |  |
| δL |  |
| λ  |  |
| δλ |  |
| h  |  |
| δh |  |
|    | **Kinematics** |
| U  | 25 |
| δU | 2 |
| f  |  |
| δf |  |
| Ω  |  |
| δΩ |  |

**Notes:**

1.

**References:**

1. Visser AW, Kiørboe T.  Plankton motility patterns and encounter rates.  Oecologia. 2006;148:538–546.
1. 249. Tomas CR. Marine Phytoplankton:  A Guide to Naked Flagellates and Coccolithophorids. London: Academic; 1993.
