**Species:** *Prorocentrum redfieldii*

**Phylum:** Dinoflagellata

**Class:** Dinophyceae

|    | **Morphology** |
|:-- | :------------: |
| B  | 33.2 |
| δB |  |
| W  | 10.28 |
| δW |  |
|    | **Flagella** |
| N  |  |
| δN |  |
| L  | 13.5 |
| δL |  |
| λ  |  |
| δλ |  |
| h  |  |
| δh |  |
|    | **Kinematics** |
| U  | 333.3 |
| δU |  |
| f  |  |
| δf |  |
| Ω  |  |
| δΩ |  |

**Notes:**

1.

**References:**

1. Sournia A.  Form and function in marine Phytoplankton.  Bio Rev. 1982;57:347–394.
1. Nordic Microalgae by Swedish Meteorological and Hydrological Institute. Accessed: 11/05/2016. http://nordicmicroalgae.org/taxon/Prorocentrum%20redfieldii
