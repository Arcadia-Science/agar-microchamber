**Species:** *Tetraflagellochloris mauritanica*

**Phylum:** Chlorophyta

**Class:** Chlorophyceae

|    | **Morphology** |
|:-- | :------------: |
| B  | 4 |
| δB | 1 |
| W  | 2.25 |
| δW | 0.25 |
|    | **Flagella** |
| N  | 4 |
| δN |  |
| L  | 23.5 |
| δL | 12.5 |
| λ  |  |
| δλ |  |
| h  |  |
| δh |  |
|    | **Kinematics** |
| U  | 300 |
| δU | 35 |
| f  | 10 |
| δf | 1 |
| Ω  |  |
| δΩ |  |

**Notes:**

1.

**References:**

1. Barsanti L, Coltelli P, Evangelista V, Frassanito AM, Gualtieri P.  Swimming patterns of the quadriflagellate *Tetraflagellochloris mauritanica* (Chlamydomonadales, Chlorophyceae).  J Phycol. 2016;52:209–218.
