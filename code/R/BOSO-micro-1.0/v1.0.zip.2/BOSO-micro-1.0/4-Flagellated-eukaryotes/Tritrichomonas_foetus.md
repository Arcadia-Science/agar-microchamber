**Species:** *Tritrichomonas foetus*

![alt text](https://github.com/marcos-fvr/BOSO-micro/blob/main/9-Figures/Tritrichomonas_foetus.png)

**Phylum:** Metamonada

**Class:** Parabasalia

|    | **Morphology** |
|:-- | :------------: |
| B  | 14.63 |
| δB | 1.3 |
| W  | 6.73 |
| δW | 1 |
|    | **Flagella** |
| N  | 4 |
| δN |  |
| L  | 12.33 |
| δL | 1.44 |
| λ  |  |
| δλ |  |
| h  |  |
| δh |  |
|    | **Kinematics** |
| U  |  |
| δU |  |
| f  |  |
| δf |  |
| Ω  |  |
| δΩ |  |

**Notes:**

1.

**References:**

1. Lenaghan SC, Nwandu-Vincent S, Reese BE, Zhang M.  Unlocking the secrets of multi-flagellated propulsion:  drawing insights from *Tritrichomonas foetus*.  J Roy Soc Interface. 2014;11(93).
