**Species:** *Alexandrium tamarense*

**Phylum:** Dinoflagellata

**Class:** Dinophyceae

|    | **Morphology** |
|:-- | :------------: |
| B  | 26.7 |
| δB | 2.6 |
| W  |  |
| δW |  |
|    | **Flagella** |
| N  |  |
| δN |  |
| L  |  |
| δL |  |
| λ  |  |
| δλ |  |
| h  |  |
| δh |  |
|    | **Kinematics** |
| U  | 200 |
| δU | 136 |
| f  |  |
| δf |  |
| Ω  |  |
| δΩ |  |

**Notes:**

1.

**References:**

1. Lewis NI, Xu W, Jericho SK, Kreuzer HJ, Jericho MH, Cembella AD.  Swimming speed of three species of *Alexandrium* (Dinophyceae) as determined by digital in-line holography.  Phycol. 2006;45:61–70.
