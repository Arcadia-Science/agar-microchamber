**Species:** *Pavlova lutheri*

**Phylum:** Haptophyta

**Class:** Pavlovophyceae

|    | **Morphology** |
|:-- | :------------: |
| B  | 6.5 |
| δB | 1.5 |
| W  |  |
| δW |  |
|    | **Flagella** |
| N  |  |
| δN |  |
| L  |  |
| δL |  |
| λ  |  |
| δλ |  |
| h  |  |
| δh |  |
|    | **Kinematics** |
| U  | 126 |
| δU |  |
| f  |  |
| δf |  |
| Ω  |  |
| δΩ |  |

**Notes:**

1.

**References:**

1. Bauerfeind E, Elbrächter M, Steiner R, Throndsen J.  Application of Laser Doppler Spectroscopy (LDS) indetermining swimming velocities of motile phytoplankton.  Marine Biology. 1986;93:323–327.
