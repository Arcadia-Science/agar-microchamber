**Species:** *Prymnesium parvum*

![alt text](https://github.com/marcos-fvr/BOSO-micro/blob/main/9-Figures/Prymnesium_parvum.png)

**Phylum:** Haptophyta

**Class:** Prymnesiophyceae

|    | **Morphology** |
|:-- | :------------: |
| B  | 7.2 |
| δB | 0.3 |
| W  | 5.4 |
| δW | 0.5 |
|    | **Flagella** |
| N  | 2 |
| δN |  |
| L  | 10 |
| δL |  |
| λ  |  |
| δλ |  |
| h  |  |
| δh |  |
|    | **Kinematics** |
| U  | 30 |
| δU |  |
| f  | 40 |
| δf |  |
| Ω  |  |
| δΩ |  |

**Notes:**

1.

**References:**

1. Dölger J, Nielsen LT, Kiørboe T, Andersen A.  Swimming and feeding of mixotrophic biflagellates.  Sci Rep.2017;7:39892.
