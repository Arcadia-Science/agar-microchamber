**Species:** *Eutreptiella gymnastica*

**Phylum:** Euglenozoa

**Class:** Euglenida (Aphagea)

|    | **Morphology** |
|:-- | :------------: |
| B  | 23.5 |
| δB | 6.5 |
| W  |  |
| δW |  |
|    | **Flagella** |
| N  | 2 |
| δN |  |
| L  | 20 |
| δL | 12 |
| λ  |  |
| δλ |  |
| h  |  |
| δh |  |
|    | **Kinematics** |
| U  | 237.5 |
| δU | 37.5 |
| f  |  |
| δf |  |
| Ω  |  |
| δΩ |  |

**Notes:**

1.

**References:**

1. Throndsen J.  Motility in some marine nanoplankton flagellates.  Norw J Zool. 1973;21:193–200.
1. 249. Tomas CR. Marine Phytoplankton:  A Guide to Naked Flagellates and Coccolithophorids. London: Academic; 1993.
