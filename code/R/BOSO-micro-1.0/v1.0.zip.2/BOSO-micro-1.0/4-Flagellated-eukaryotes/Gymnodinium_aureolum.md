**Species:** *Gymnodinium aureolum*

**Phylum:** Dinoflagellata

**Class:** Dinophyceae

|    | **Morphology** |
|:-- | :------------: |
| B  |  |
| δB |  |
| W  |  |
| δW |  |
|    | **Flagella** |
| N  |  |
| δN |  |
| L  |  |
| δL |  |
| λ  |  |
| δλ |  |
| h  |  |
| δh |  |
|    | **Kinematics** |
| U  | 394 |
| δU |  |
| f  |  |
| δf |  |
| Ω  |  |
| δΩ |  |

**Notes:**

1.

**References:**

1. Meunier CL, Schulz K, Boersma M, Malzahn AM.  Impact of swimming behaviour and nutrient limitation on predator-prey interactions in pelagic microbial food webs.  J Exp Mar Biol Ecol. 2013;446:29–35.
