**Species:** *Ceratium lineatum*

**Phylum:** Dinoflagellata

**Class:** Dinophyceae

|    | **Morphology** |
|:-- | :------------: |
| B  | 82.1 |
| δB |  |
| W  | 26.8 |
| δW |  |
|    | **Flagella** |
| N  |  |
| δN |  |
| L  |  |
| δL |  |
| λ  | 18.6 |
| δλ |  |
| h  | 1.3 |
| δh |  |
|    | **Kinematics** |
| U  | 36 |
| δU |  |
| f  |  |
| δf |  |
| Ω  | 0.63 |
| δΩ |  |

**Notes:**

1.

**References:**

1. Fenchel T.  How dinoflagellates swim.  Protist. 2001;152:329–338.
