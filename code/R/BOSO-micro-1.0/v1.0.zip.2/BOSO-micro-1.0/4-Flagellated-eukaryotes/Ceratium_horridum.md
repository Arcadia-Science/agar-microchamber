**Species:** *Ceratium horridum*

**Phylum:** Dinoflagellata

**Class:** Dinophyceae

|    | **Morphology** |
|:-- | :------------: |
| B  | 225 |
| δB | 25 |
| W  | 50 |
| δW | 10 |
|    | **Flagella** |
| N  |  |
| δN |  |
| L  |  |
| δL |  |
| λ  |  |
| δλ |  |
| h  |  |
| δh |  |
|    | **Kinematics** |
| U  | 20.8 |
| δU | 12.5 |
| f  |  |
| δf |  |
| Ω  |  |
| δΩ |  |

**Notes:**

1.

**References:**

1. Peters N.  Uber Orts- und Geisselbewegung bei marinen Dinoflagellaten.  Arch Protistenkd. 1929;67:291–321.
1. Olenina I, *et al*.  Biovolumes and Size-Classes of Phytoplankton in the Baltic Sea.  Balt Sea Environ Proc. 2006;106:144.
