**Species:** *Dinophysis acuta*

**Phylum:** Dinoflagellata

**Class:** Dinophyceae

|    | **Morphology** |
|:-- | :------------: |
| B  | 65 |
| δB |  |
| W  | 55 |
| δW |  |
|    | **Flagella** |
| N  | 2 |
| δN |  |
| L  | 65 |
| δL |  |
| λ  |  |
| δλ |  |
| h  | 11 |
| δh |  |
|    | **Kinematics** |
| U  | 500 |
| δU |  |
| f  |  |
| δf |  |
| Ω  |  |
| δΩ |  |

**Notes:**

1.

**References:**

1. Peters N.  Uber Orts- und Geisselbewegung bei marinen Dinoflagellaten.  Arch Protistenkd. 1929;67:291–321.
1. Sleigh MA.  Patterns of ciliary beating.  In:  Aspects of Cell Motility, Symp. Soc. Exp. Biol.. vol. 22; 1968. p. 131–150.
