**Species:** *Crithidia deanei*

**Phylum:** Euglenozoa

**Class:** Kinetoplastea

|    | **Morphology** |
|:-- | :------------: |
| B  | 7.4 |
| δB | 0.2 |
| W  |  |
| δW |  |
|    | **Flagella** |
| N  | 1 |
| δN |  |
| L  | 13.1 |
| δL | 0.4 |
| λ  | 11.7 |
| δλ | 0.2 |
| h  | 2.2 |
| δh | 0.05 |
|    | **Kinematics** |
| U  | 45.6 |
| δU | 1.5 |
| f  | 40.5 |
| δf | 0.8 |
| Ω  |  |
| δΩ |  |

**Notes:**

1.

**References:**

1. Gadelha C, Wickstead B, Gul K.  Flagellar and Ciliary Beating in Trypanosome Motility.  Cell Motil Cytosk.2007;64:629–643.
