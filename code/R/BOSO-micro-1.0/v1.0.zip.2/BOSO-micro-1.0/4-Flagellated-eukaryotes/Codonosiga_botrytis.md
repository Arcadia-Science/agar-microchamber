**Species:** *Codonosiga botrytis*

![alt text](https://github.com/marcos-fvr/BOSO-micro/blob/main/9-Figures/Codonosiga_botrytis.png)

**Phylum:** -

**Class:** Choanoflagellatea

|    | **Morphology** |
|:-- | :------------: |
| B  | 15 |
| δB |  |
| W  | 5 |
| δW |  |
|    | **Flagella** |
| N  | 1 |
| δN |  |
| L  | 30 |
| δL |  |
| λ  | 17.9 |
| δλ |  |
| h  |  |
| δh |  |
|    | **Kinematics** |
| U  |  |
| δU |  |
| f  | 28 |
| δf |  |
| Ω  |  |
| δΩ |  |

**Notes:**

1.

**References:**

1. Sleigh MA.  Patterns of ciliary beating.  In:  Aspects of Cell Motility, Symp. Soc. Exp. Biol.. vol. 22; 1968. p. 131–150.
1. Sleigh MA.  The Biology of Protozoa.  London:  Arnold; 1973.
1. Lapage G. Notes on the Choanoflagellate, *Codosiga botrytis*, Ehrbg..  Accessed: 07/07/2016. http://jcs.biologists.org/content/joces/s2-69/275/471.full.pdf
