**Species:** *Monostroma angicava*

**Phylum:** Chlorophyta

**Class:** Ulvophyceae

|    | **Morphology** |
|:-- | :------------: |
| B  | 6.695 |
| δB | 0.885 |
| W  | 3.33 |
| δW | 0.4 |
|    | **Flagella** |
| N  | 2 |
| δN |  |
| L  | 13.685 |
| δL | 0.645 |
| λ  |  |
| δλ |  |
| h  |  |
| δh |  |
|    | **Kinematics** |
| U  | 170.55 |
| δU | 12.15 |
| f  |  |
| δf |  |
| Ω  |  |
| δΩ |  |

**Notes:**

1.

**References:**

1. Togashi T, Motomura T, Ichimura T.  Production of anisogametes and gamete motility dimorphism in *Monostroma angicava*.  Sex Plant Reprod. 1997;10:261–268.
