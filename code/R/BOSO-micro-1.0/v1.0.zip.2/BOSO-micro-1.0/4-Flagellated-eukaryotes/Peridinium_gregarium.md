**Species:** *Peridinium gregarium*

**Phylum:** Dinoflagellata

**Class:** Dinophyceae

|    | **Morphology** |
|:-- | :------------: |
| B  | 32.5 |
| δB | 2.5 |
| W  | 32.5 |
| δW | 2.5 |
|    | **Flagella** |
| N  | 2 |
| δN |  |
| L  | 200 |
| δL |  |
| λ  |  |
| δλ |  |
| h  |  |
| δh |  |
|    | **Kinematics** |
| U  | 1291.7 |
| δU | 513.9 |
| f  |  |
| δf |  |
| Ω  |  |
| δΩ |  |

**Notes:**

1.

**References:**

1. Levandowsky M, Kaneta PJ.  Behaviour in Dinoflagellates.  In: Taylor FJR, editor. The Biology of Dinoflagellates (Botanical Monographs vol. 21); 1987.
1. Lombard EH, Capon B.Peridinium gregarium, a new species of dinoflagellate.  J Phycol. 1971;7:184–187.
