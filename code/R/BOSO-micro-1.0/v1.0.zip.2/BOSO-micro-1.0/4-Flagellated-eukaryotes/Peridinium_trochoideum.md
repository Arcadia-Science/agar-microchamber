**Species:** *Peridinium trochoideum*

**Phylum:** Dinoflagellata

**Class:** Dinophyceae

|    | **Morphology** |
|:-- | :------------: |
| B  | 25 |
| δB | 5 |
| W  | 19 |
| δW | 4 |
|    | **Flagella** |
| N  |  |
| δN |  |
| L  |  |
| δL |  |
| λ  |  |
| δλ |  |
| h  |  |
| δh |  |
|    | **Kinematics** |
| U  | 53 |
| δU | 17 |
| f  |  |
| δf |  |
| Ω  |  |
| δΩ |  |

**Notes:**

1.

**References:**

1. Levandowsky M, Kaneta PJ.  Behaviour in Dinoflagellates.  In: Taylor FJR, editor. The Biology of Dinoflagellates (Botanical Monographs vol. 21); 1987.
1. Lemmermann E.  Algen I (Schizophyceen, Flagellaten, Peridineen).  In:  Kryptogamenflora der Mark Brandenburg undangrenzender Gebiete herausgegeben von dem Botanishcen Verein der Provinz Brandenburg. vol. 3. Leipzig:  Verlagvon Grebrüder Borntraeger; 1910. p. 497–712
