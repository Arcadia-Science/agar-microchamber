**Species:** *Ceratium macroceros*

**Phylum:** Dinoflagellata

**Class:** Dinophyceae

|    | **Morphology** |
|:-- | :------------: |
| B  | 50 |
| δB | 10 |
| W  |  |
| δW |  |
|    | **Flagella** |
| N  |  |
| δN |  |
| L  |  |
| δL |  |
| λ  |  |
| δλ |  |
| h  |  |
| δh |  |
|    | **Kinematics** |
| U  | 15.4 |
| δU |  |
| f  |  |
| δf |  |
| Ω  |  |
| δΩ |  |

**Notes:**

1.

**References:**

1. Peters N.  Uber Orts- und Geisselbewegung bei marinen Dinoflagellaten.  Arch Protistenkd. 1929;67:291–321.
1. Olenina I, *et al*.  Biovolumes and Size-Classes of Phytoplankton in the Baltic Sea.  Balt Sea Environ Proc. 2006;106:144.
