**Species:** *Alexandrium ostenfeldii*

**Phylum:** Dinoflagellata

**Class:** Dinophyceae

|    | **Morphology** |
|:-- | :------------: |
| B  | 41.1 |
| δB | 4.5 |
| W  |  |
| δW |  |
|    | **Flagella** |
| N  |  |
| δN |  |
| L  |  |
| δL |  |
| λ  |  |
| δλ |  |
| h  |  |
| δh |  |
|    | **Kinematics** |
| U  | 110.5 |
| δU | 73.5 |
| f  |  |
| δf |  |
| Ω  |  |
| δΩ |  |

**Notes:**

1.

**References:**

1. Lewis NI, Xu W, Jericho SK, Kreuzer HJ, Jericho MH, Cembella AD.  Swimming speed of three species of *Alexandrium* (Dinophyceae) as determined by digital in-line holography.  Phycol. 2006;45:61–70.
