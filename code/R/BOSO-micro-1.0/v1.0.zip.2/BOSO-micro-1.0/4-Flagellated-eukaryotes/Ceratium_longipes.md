**Species:** *Ceratium longipes*

**Phylum:** Dinoflagellata

**Class:** Dinophyceae

|    | **Morphology** |
|:-- | :------------: |
| B  | 210 |
| δB |  |
| W  | 54 |
| δW | 3 |
|    | **Flagella** |
| N  |  |
| δN |  |
| L  |  |
| δL |  |
| λ  |  |
| δλ |  |
| h  |  |
| δh |  |
|    | **Kinematics** |
| U  | 166 |
| δU |  |
| f  |  |
| δf |  |
| Ω  |  |
| δΩ |  |

**Notes:**

1.

**References:**

1. Peters N.  Uber Orts- und Geisselbewegung bei marinen Dinoflagellaten.  Arch Protistenkd. 1929;67:291–321.
1. Kudo RR.  Protozoology.  Springfield:  Thomas; 1954.
