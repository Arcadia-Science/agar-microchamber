**Species:** *Prorocentrum micans*

**Phylum:** Dinoflagellata

**Class:** Dinophyceae

|    | **Morphology** |
|:-- | :------------: |
| B  | 45 |
| δB | 5 |
| W  |  |
| δW |  |
|    | **Flagella** |
| N  |  |
| δN |  |
| L  |  |
| δL |  |
| λ  |  |
| δλ |  |
| h  |  |
| δh |  |
|    | **Kinematics** |
| U  | 329.1 |
| δU | 281.9 |
| f  |  |
| δf |  |
| Ω  |  |
| δΩ |  |

**Notes:**

1.

**References:**

1. Bauerfeind E, Elbrächter M, Steiner R, Throndsen J.  Application of Laser Doppler Spectroscopy (LDS) indetermining swimming velocities of motile phytoplankton.  Marine Biology. 1986;93:323–327.
1. Levandowsky M, Kaneta PJ.  Behaviour in Dinoflagellates.  In: Taylor FJR, editor. The Biology of Dinoflagellates (Botanical Monographs vol. 21); 1987.
1. Hansen PJ, Bjørnsen PK, Hansen BW.  Zooplankton grazing and growth:  Scaling within the 2-2,000-μm body sizerange.  Limnology and Oceanography. 1997;42(4):687–704.
