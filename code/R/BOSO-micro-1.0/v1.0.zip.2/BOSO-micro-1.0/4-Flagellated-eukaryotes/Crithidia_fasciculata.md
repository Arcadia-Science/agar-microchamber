**Species:** *Crithidia fasciculata*

**Phylum:** Euglenozoa

**Class:** Kinetoplastea

|    | **Morphology** |
|:-- | :------------: |
| B  | 11.1 |
| δB | 0.3 |
| W  |  |
| δW |  |
|    | **Flagella** |
| N  | 1 |
| δN |  |
| L  | 15.1 |
| δL | 0.5 |
| λ  | 11.6 |
| δλ | 0.2 |
| h  | 2.2 |
| δh | 0.07 |
|    | **Kinematics** |
| U  | 54.3 |
| δU | 2.6 |
| f  | 60 |
| δf | 2.3 |
| Ω  |  |
| δΩ |  |

**Notes:**

1.

**References:**

1. Gadelha C, Wickstead B, Gul K.  Flagellar and Ciliary Beating in Trypanosome Motility.  Cell Motil Cytosk.2007;64:629–643.
