**Species:** *Monas stigmata*

**Phylum:** Ochrophyta (Heterokont)

**Class:** Chrysophyceae

|    | **Morphology** |
|:-- | :------------: |
| B  | 6 |
| δB |  |
| W  |  |
| δW |  |
|    | **Flagella** |
| N  | 2 |
| δN |  |
| L  | 9 |
| δL | 6 |
| λ  |  |
| δλ |  |
| h  |  |
| δh |  |
|    | **Kinematics** |
| U  | 269 |
| δU |  |
| f  | 47.75 |
| δf |  |
| Ω  |  |
| δΩ |  |

**Notes:**

1.

**References:**

1. Lowndes AG.  The swimming of *Monas stigmatica* Pringsheim and *Peranema trichophorum* (Ehrbg) Stein and *Volvox* sp. Additional experiments on the working of a flagellum.  Proc Zool Soc London. 1944;114A:325–338.
1. Gittleson SM, Hotchkiss SK, Valencia FG.  Locomotion in the marine dinoflagellate *Amphidinium carterae* (Hulburt).Trans Am Microsc Soc. 1974;93:101–5.
