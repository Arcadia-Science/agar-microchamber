**Species:** *Hymenomonas carterae*

**Phylum:** Haptophyta

**Class:** Prymnesiophyceae

|    | **Morphology** |
|:-- | :------------: |
| B  | 12.5 |
| δB | 2.5 |
| W  |  |
| δW |  |
|    | **Flagella** |
| N  |  |
| δN |  |
| L  |  |
| δL |  |
| λ  |  |
| δλ |  |
| h  |  |
| δh |  |
|    | **Kinematics** |
| U  | 87 |
| δU | 26 |
| f  |  |
| δf |  |
| Ω  |  |
| δΩ |  |

**Notes:**

1.

**References:**

1. Bauerfeind E, Elbrächter M, Steiner R, Throndsen J.  Application of Laser Doppler Spectroscopy (LDS) indetermining swimming velocities of motile phytoplankton.  Marine Biology. 1986;93:323–327.
