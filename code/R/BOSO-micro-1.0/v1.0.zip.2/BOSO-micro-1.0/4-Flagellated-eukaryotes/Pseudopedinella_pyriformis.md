**Species:** *Pseudopedinella pyriformis*

**Phylum:** Ochrophyta (Heterokont)

**Class:** Dictyochophyceae

|    | **Morphology** |
|:-- | :------------: |
| B  | 6.5 |
| δB | 1.5 |
| W  |  |
| δW |  |
|    | **Flagella** |
| N  | 1 |
| δN |  |
| L  | 27.5 |
| δL | 12.5 |
| λ  |  |
| δλ |  |
| h  |  |
| δh |  |
|    | **Kinematics** |
| U  | 100 |
| δU | 10 |
| f  |  |
| δf |  |
| Ω  |  |
| δΩ |  |

**Notes:**

1.

**References:**

1. Throndsen J.  Motility in some marine nanoplankton flagellates.  Norw J Zool. 1973;21:193–200.
1. 249. Tomas CR. Marine Phytoplankton:  A Guide to Naked Flagellates and Coccolithophorids. London: Academic; 1993.
