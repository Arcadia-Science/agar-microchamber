**Species:** *Trachelomonas volvocina*

**Phylum:** Euglenozoa

**Class:** Euglenida (Euglenophyceae)

|    | **Morphology** |
|:-- | :------------: |
| B  | 25 |
| δB |  |
| W  |  |
| δW |  |
|    | **Flagella** |
| N  |  |
| δN |  |
| L  | 50 |
| δL |  |
| λ  |  |
| δλ |  |
| h  |  |
| δh |  |
|    | **Kinematics** |
| U  |  |
| δU |  |
| f  |  |
| δf |  |
| Ω  |  |
| δΩ |  |

**Notes:**

1.

**References:**

1. Votta JJ, Jahn TL, Griffith DL, Fonseca JR.  Nature of the flagellar beat in *Trachelomonas volvocina*, *Rhabdomonas spiralis*, *Menoidium cultellus* and *Chilomonas* paramecium.  Trans Am Microsc Soc. 1971;90:404 12.
